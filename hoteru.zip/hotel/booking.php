<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $checkin = $_POST['checkin'];
    $checkout = $_POST['checkout'];
    $adults = $_POST['adults'];
    $children = $_POST['children'];
    $room_type = $_POST['room_type'];
    $special_requests = $_POST['special_requests'];

    $sql = "INSERT INTO bookings (name, email, checkin, checkout, adults, children, room_type, special_requests) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$name, $email, $checkin, $checkout, $adults, $children, $room_type, $special_requests]);

    echo "Бронирование успешно добавлено!";
}
?>
